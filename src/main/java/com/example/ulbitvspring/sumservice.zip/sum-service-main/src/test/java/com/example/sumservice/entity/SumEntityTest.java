package com.example.sumservice.entity;

class SumEntityTest {

}