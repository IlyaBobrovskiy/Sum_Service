package com.example.sumservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SumApplication {

    public static void main(String[] args) {
        SpringApplication.run(SumApplication.class, args);
    }

}
