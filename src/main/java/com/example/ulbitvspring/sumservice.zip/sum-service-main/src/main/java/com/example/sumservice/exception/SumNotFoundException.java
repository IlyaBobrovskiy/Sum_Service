package com.example.sumservice.exception;

public class SumNotFoundException extends Exception {
    public SumNotFoundException(String message) {
        super(message);
    }
}
